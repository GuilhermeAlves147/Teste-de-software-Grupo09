package com.ucb.market.repository;

import com.ucb.market.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, Integer> {
    Optional<Cart> findFirstByClientId(Integer clientId);
}